// 1. Elementos da Shell
const menuButtons = document.querySelectorAll('.menu-btn');
const iframe = document.getElementById('moduleFrame');

// Fila temporária para envio de cliente via postMessage
let clientePendente = null;

// 2. Navegação entre Módulos pela Sidebar
if (menuButtons.length > 0 && iframe) {
  menuButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      menuButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const targetModule = btn.getAttribute('data-module');
      if (targetModule) {
        iframe.src = targetModule;
      }
    });
  });

  iframe.addEventListener('load', () => {
    if (clientePendente) {
      iframe.contentWindow.postMessage({
        action: 'LOAD_CUSTOMER_DATA',
        customer: clientePendente
      }, '*');
      clientePendente = null;
    }
  });
}

// 3. Recebe a requisição dos Módulos para criar pedido / selecionar cliente
window.addEventListener('message', (event) => {
  const { action, data } = event.data || {};

  if (action === 'SELECT_CUSTOMER_FOR_ORDER') {
    console.log('Cliente selecionado recebido na Shell:', data);
    clientePendente = data;
    const atendimentoBtn = document.querySelector('[data-module="modules/01-atendimento/index.html"]');
    if (atendimentoBtn) {
      atendimentoBtn.click();
    }
  }
});

// ==========================================
// CENTRAL DE COMUNICAÇÃO COM A API MYSQL
// ==========================================
const API_URL = 'http://localhost:3000/api';

window.ApiDB = {
  async getProdutos() {
    try {
      const response = await fetch(`${API_URL}/produtos`);
      if (!response.ok) throw new Error('Erro ao carregar produtos');
      return await response.json();
    } catch (error) {
      console.error('Erro na API (getProdutos):', error);
      return [];
    }
  },

  async getPedidos() {
    try {
      const response = await fetch(`${API_URL}/pedidos`);
      if (!response.ok) throw new Error('Erro ao carregar pedidos');
      return await response.json();
    } catch (error) {
      console.error('Erro na API (getPedidos):', error);
      return [];
    }
  },

  async salvarPedido(dadosPedido) {
    try {
      const response = await fetch(`${API_URL}/pedidos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dadosPedido)
      });
      if (!response.ok) throw new Error('Erro ao criar pedido');
      return await response.json();
    } catch (error) {
      console.error('Erro na API (salvarPedido):', error);
      throw error;
    }
  }
};

// ==========================================
// BANCO LOCAL AUXILIAR (LocalStorage)
// ==========================================
const LocalDB = {
  get(key) {
    const data = localStorage.getItem(`pizzaria_${key}`);
    return data ? JSON.parse(data) : [];
  },
  save(key, data) {
    localStorage.setItem(`pizzaria_${key}`, JSON.stringify(data));
  },
  init() {
    if (!localStorage.getItem('pizzaria_clientes')) this.save('clientes', []);
    if (!localStorage.getItem('pizzaria_caixa')) this.save('caixa', []);
  }
};

// ==========================================
// GESTÃO DA TABELA DE PREÇOS / CARDÁPIO
// ==========================================
let categoriaAtual = 'Pizza Salgada';

function mudarCategoria(categoria) {
  categoriaAtual = categoria;
  
  // Atualiza a classe ativa nos botões de abas
  document.querySelectorAll('.tab-btn').forEach(btn => {
    if (btn.textContent.includes(categoria)) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  renderizarCardapio();
}

async function renderizarCardapio() {
  const grid = document.getElementById('gridCardapio');
  if (!grid) return; // Se não estiver na página da tabela de preços, interrompe

  const buscaInput = document.getElementById('buscaCardapio');
  const termoBusca = buscaInput ? buscaInput.value.toLowerCase() : '';

  grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--text-main, #333);">A carregar cardápio do servidor...</p>';

  const produtos = await window.ApiDB.getProdutos();

  // Filtra rigorosamente pela categoria selecionada na aba e pelo termo de busca
  const produtosFiltrados = produtos.filter(p => {
    const catProd = (p.categoria || '').trim();
    const matchCategoria = (catProd.toLowerCase() === categoriaAtual.toLowerCase());

    const matchBusca = p.nome.toLowerCase().includes(termoBusca) || 
                       (p.descricao && p.descricao.toLowerCase().includes(termoBusca));

    return matchCategoria && matchBusca;
  });

  grid.innerHTML = '';

  if (produtosFiltrados.length === 0) {
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--text-main, #333);">Nenhum item encontrado nesta categoria.</p>';
    return;
  }

  produtosFiltrados.forEach(produto => {
    const card = document.createElement('div');
    card.className = 'cardapio-card'; // Mantém a classe original do design
    card.innerHTML = `
      <div style="padding: 15px; display: flex; flex-direction: column; height: 100%; justify-content: space-between;">
        <div>
          <h4 style="margin-bottom: 8px; font-size: 1.1rem; color: var(--text-main);">${produto.nome}</h4>
          <p style="font-size: 0.85rem; color: var(--text-muted, #666); margin-bottom: 12px;">${produto.descricao || ''}</p>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto;">
          <span style="font-weight: bold; font-size: 1rem; color: var(--cheese-gold, #e67e22);">R$ ${Number(produto.preco).toFixed(2).replace('.', ',')}</span>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

// ==========================================
// GESTÃO DE TEMAS (Claro / Escuro)
// ==========================================
function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('bella_massa_theme', theme);
}

// Inicialização ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
  LocalDB.init();

  // Aplica o tema guardado
  const savedTheme = localStorage.getItem('bella_massa_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);

  // Se a tabela de preços estiver presente na página, carrega os dados da API
  if (document.getElementById('gridCardapio')) {
    renderizarCardapio();
  }
});